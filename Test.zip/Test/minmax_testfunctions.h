#ifndef __MINMAX_TESTFUNCTIONS_H__
#define __MINMAX_TESTFUNCTIONS_H__

extern void Mytestfunction_min(void);

#endif
